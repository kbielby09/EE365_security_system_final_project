

/***************************** Include Files *******************************/
#include "seven_segment_display_slave.h"

/************************** Function Definitions ***************************/
